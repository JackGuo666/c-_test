﻿namespace Modbus.Core
{
    public enum SessionState
    {
        Identified,
        Unidentified,
        Expired
    }
}