﻿namespace Modbus.Core
{
    public class DefaultHandshake
    {
        public int SlaveAddress { get; set; }
    }
}